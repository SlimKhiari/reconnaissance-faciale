Il faut installer eclipse IDE for java EE developers comme IDE et Tomcat 10 comme serveur

quand vous lancer le programme assurez vous que le lien localhost est:
http://localhost:8080/projet_web_jee/login

Pour la page de login il faut mettre comme login�:
Email�: chahed2014@gmail.com
Password�: 1234

