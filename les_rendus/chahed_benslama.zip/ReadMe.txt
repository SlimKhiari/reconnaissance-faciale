Il faut installer eclipse comme IDE et Tomcat 10 comme serveur
Pour la page de login il faut mettre comme login�:
Email�: chahed2014@gmail.com
Password�: 1234

