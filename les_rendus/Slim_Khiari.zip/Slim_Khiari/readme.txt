Des informations utiles pour lancer "reconnaitre.py"
os utilisé : linux ubuntu 20.04

1) version de python : 3

2) installation de l'API face recognition : pip3 install face_recognition

3) installation de cv2 (open cv de python) : sudo apt-get install python3-opencv

4) installation de mysql et de mysqlworkbrench pour la base de données (changer les parametres de connexion pour bien se connecter) et pyfirmata (pour l'arduino) 

5) pour lancer le fichier reconnaitre.py : python3 reconnaitre.py